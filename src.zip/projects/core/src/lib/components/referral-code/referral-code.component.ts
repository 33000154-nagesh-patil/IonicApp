import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-referral-code',
  templateUrl: './referral-code.component.html',
  styleUrls: ['./referral-code.component.scss'],
})
export class ReferralCodeComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
