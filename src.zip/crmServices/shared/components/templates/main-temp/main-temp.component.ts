import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-main-temp',
  templateUrl: './main-temp.component.html',
  styleUrls: ['./main-temp.component.scss'],
})
export class MainTempComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
