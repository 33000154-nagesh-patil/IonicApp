import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-detail-temp',
  templateUrl: './detail-temp.component.html',
  styleUrls: ['./detail-temp.component.scss'],
})
export class DetailTempComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
